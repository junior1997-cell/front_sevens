<!-- Favicon -->
<link rel="shortcut icon" href="../assets/svg/default/logo-short.svg">

<!-- Font -->
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&amp;display=swap" rel="stylesheet">

<!-- CSS Implementing Plugins -->
<link rel="stylesheet" href="../assets/css/vendor.min.css">

<!-- CSS Front Template -->
<link rel="stylesheet" href="../assets/css/theme.minc619.css?v=1.0">

<!-- DataTables -->
<link rel="stylesheet" type="text/css" href="../plugins/datatables2/jquery.dataTables.min.css">    
<link rel="stylesheet" type="text/css" href="../plugins/datatables2/buttons.dataTables.min.css" rel="stylesheet"/>
<link rel="stylesheet" type="text/css" href="../plugins/datatables2/responsive.dataTables.min.css" rel="stylesheet"/>

<!-- Select2 -->
<link rel="stylesheet" href="../plugins/select2/css/select2.min.css">

<!-- Toastr -->
<link rel="stylesheet" href="../plugins/toastr/toastr.min.css">

<!-- summernote -->
<link rel="stylesheet" href="../plugins/summernote/summernote-bs4.min.css">

<!-- CSS Front Template -->
<link rel="stylesheet" href="../dist/css/style_new.css">